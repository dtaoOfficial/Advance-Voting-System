package com.vote.digital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
